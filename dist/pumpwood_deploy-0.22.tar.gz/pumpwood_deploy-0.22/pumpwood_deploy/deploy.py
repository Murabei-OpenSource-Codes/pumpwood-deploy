"""
pumpwood deploy.

.
"""

import os
import stat
import random
import string
import shutil
import base64

from slugify import slugify
from .microservices.standard.standard import \
    StandardMicroservices
from .microservices.load_balancer.load_balancer import \
    LoadBalancerMicroservice
from .endpoint_services.endpoint_services import \
    EndPointServices
from .kubernets.kubernets import Kubernets


class DeployPumpWood():
    """Class to perform PumpWood Deploy."""

    create_kube_cmd = 'SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"\n' + \
        'kubectl delete -f $SCRIPTPATH/{file}\n' +\
        'kubectl create -f $SCRIPTPATH/{file}'

    def __init__(
      self, bucket_key_path: str, haproxy_stats_user: str,
      haproxy_stats_password: str, beatbox_user: str, beatbox_password: str,
      beatbox_config_path: str, beatbox_version: str, gateway_public_ip: str,
      cluster_name: str, cluster_zone: str, cluster_project: str,
      gateway_ssl_cert_path: str, gateway_ssl_key_path: str,
      gateway_ssl_dhparam_path: str, load_balancer_firewall_ips: list,
      version_nginx_gateway: str):
        """
        __init__.

        Args:
          bucket_key_path (str): path to bucket service user path.
          haproxy_stats_user (str): user of haparoxy stats user.
          haproxy_stats_password (str): password of haproxy stats.
          beatbox_user (str): User of beatbox microservice.
          beatbox_password (str): Password of beatbox microservice
          beatbox_conf_path (str): Path to beatbox configuration file.
          beatbox_version (str): Version of beatbox image.
          gateway_public_ip (str): IP of the gateway loadbalancer.
          cluster_zone (str): Kubernets cluster zone.
          cluster_project (str): Kubernets project name.
          gateway_ssl_cert_path (str): Path to ssl certification path.
          gateway_ssl_key_path (str): Path to ssl key.
          gateway_ssl_dhparam_path (str): Dhparam ssl parameter.
          load_balancer_firewall_ips (list): List of the allowed ips on
            firewall.
          version_nginx_gateway (str): Version of the NGINX gateway.
        """
        self.deploy = []

        self.kube_client = Kubernets(
            cluster_name=cluster_name, zone=cluster_zone,
            project=cluster_project)

        rabbitmq_secret = ''.join([random.choice(
            string.ascii_uppercase + string.digits) for i in range(20)])

        standard_microservices = StandardMicroservices(
            rabbit_username='rabbitmq', rabbit_password=rabbitmq_secret,
            beatbox_user=beatbox_user, beatbox_password=beatbox_password,
            beatbox_config_path=beatbox_config_path,
            beatbox_version=beatbox_version,
            bucket_key_path=bucket_key_path)

        self.microsservices_to_deploy = [EndPointServices()]
        self.microsservices_to_deploy.append(standard_microservices)
        self.base_path = os.getcwd()

        self.haproxy_stats_user = haproxy_stats_user
        self.haproxy_stats_password = haproxy_stats_password

        self._beatbox_user = base64.b64encode(beatbox_user.encode()).decode()
        self._beatbox_password = base64.b64encode(
            beatbox_password.encode()).decode()

        self.kube_dns_ip = self.kube_client.get_cluster_dns_ip()
        self.gateway_public_ip = gateway_public_ip
        self.gateway_ssl_cert_path = gateway_ssl_cert_path
        self.gateway_ssl_key_path = gateway_ssl_key_path
        self.gateway_ssl_dhparam_path = gateway_ssl_dhparam_path

        self.version_nginx_gateway = version_nginx_gateway

        self.load_balancer_firewall_ips = load_balancer_firewall_ips

    def add_microservice(self, microservice):
        """
        add_microservice.

        .
        """
        self.microsservices_to_deploy.append(microservice)

    def create_deploy_files(self):
        """create_deploy_files."""
        load_balancer_config = {'acls': [],
                                'services': []}
        sevice_cmds = []
        deploy_cmds = []
        load_balancer_cmds = []

        counter = 0
        service_counter = 0

        if os.path.exists('outputs/deploy_output'):
            shutil.rmtree('outputs/deploy_output')
        os.makedirs('outputs/deploy_output')
        os.makedirs('outputs/deploy_output/resources/')

        if os.path.exists('outputs/services_output'):
            shutil.rmtree('outputs/services_output')
        os.makedirs('outputs/services_output')
        os.makedirs('outputs/services_output/resources/')

        if os.path.exists('outputs/load_balancer_output'):
            shutil.rmtree('outputs/load_balancer_output')
        os.makedirs('outputs/load_balancer_output')
        os.makedirs('outputs/load_balancer_output/resources/')

        print('###Creating microservices files:')
        for m in self.microsservices_to_deploy:
            print('\nProcessing: ' + str(m))
            temp_deployments = m.create_deployment_file()
            for d in temp_deployments:
                if d['type'] in ['secrets', 'deploy', 'volume']:
                    file_name_temp = 'resources/{counter}__{name}.yml'
                    file_name = file_name_temp.format(
                        counter=counter,
                        name=d['name'])

                    print('Creating secrets/deploy: ' + file_name)
                    with open('outputs/deploy_output/' +
                              file_name, 'w') as file:
                        file.write(d['content'])

                    file_name_sh_temp = 'outputs/deploy_output/' +\
                                        '{counter}__{name}.sh'
                    file_name_sh = file_name_sh_temp.format(
                        counter=counter,
                        name=d['name'])

                    with open(file_name_sh, 'w') as file:
                        content = self.create_kube_cmd.format(file=file_name)
                        file.write(content)
                    os.chmod(file_name_sh, stat.S_IRWXU)

                    deploy_cmds.append({
                        'command': 'run', 'file': file_name_sh,
                        'sleep': d.get('sleep')})
                    counter = counter + 1

                elif d['type'] == 'secrets_file':
                    command_formated = d['content']
                    file_name_temp = 'outputs/deploy_output/' + \
                                     '{counter}__{name}.sh'
                    file_name = file_name_temp.format(
                        counter=counter,
                        name=d['name'])

                    print('Creating secrets_file: ' + file_name)
                    with open(file_name, 'w') as file:
                        file.write(command_formated)
                    os.chmod(file_name, stat.S_IRWXU)
                    deploy_cmds.append({
                        'command': 'run', 'file': file_name,
                        'sleep': d.get('sleep')})
                    counter = counter + 1

                elif d['type'] == 'configmap':
                    file_name_resource_temp = 'resources/{name}'
                    file_name_resource = file_name_resource_temp.format(
                        name=d['file_name'])

                    with open('outputs/deploy_output/' +
                              file_name_resource, 'w') as file:
                        file.write(d['content'])

                    command_formated = None
                    if d.get('keyname') is None:
                        command_text = \
                            'SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"\n' + \
                            "kubectl delete configmap {name};\n" + \
                            "kubectl create configmap {name} " + \
                            '--from-file="$SCRIPTPATH/{file_name}"'

                        command_formated = command_text.format(
                            name=d['name'], file_name=file_name_resource)
                    else:
                        command_text = \
                            'SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"\n' + \
                            "kubectl delete configmap {name};\n" + \
                            "kubectl create configmap {name} " + \
                            '--from-file="{keyname}=$SCRIPTPATH/{file_name}"'
                        command_formated = command_text.format(
                            name=d['name'], file_name=file_name_resource,
                            keyname=d['keyname'])

                    file_name_temp = 'outputs/deploy_output/' + \
                                     '{counter}__{name}.sh'
                    file_name = file_name_temp.format(
                        counter=counter,
                        name=d['name'])

                    print('Creating configmap: ' + file_name)
                    with open(file_name, 'w') as file:
                        file.write(command_formated)
                    deploy_cmds.append({'command': 'run', 'file': file_name,
                                        'sleep': d.get('sleep')})
                    os.chmod(file_name, stat.S_IRWXU)
                    counter = counter + 1

                elif d['type'] == 'services':
                    file_name_temp = 'resources/{service_counter}__{name}.yml'
                    file_name = file_name_temp.format(
                        service_counter=service_counter,
                        name=d['name'])

                    print('Creating services: ' + file_name)
                    with open('outputs/services_output/' +
                              file_name, 'w') as file:
                        file.write(d['content'])

                    file_name_sh_temp = \
                        'outputs/services_output/' +\
                        '{service_counter}__{name}.sh'
                    file_name_sh = file_name_sh_temp .format(
                        service_counter=service_counter,
                        name=d['name'])

                    with open(file_name_sh, 'w') as file:
                        content = self.create_kube_cmd.format(file=file_name)
                        file.write(content)

                    os.chmod(file_name_sh, stat.S_IRWXU)
                    sevice_cmds.append({'command': 'run', 'file': file_name_sh,
                                        'sleep': d.get('sleep')})
                    service_counter = service_counter + 1

                elif d['type'] == 'endpoint_services':
                    file_name_temp = 'resources/{service_counter}__{name}.yml'
                    file_name = file_name_temp.format(
                        service_counter=service_counter,
                        name=d['name'])

                    print('Creating endpoint_services: ' + file_name)
                    with open('outputs/services_output/' +
                              file_name, 'w') as file:
                        file.write(d['content'])

                    file_name_sh_temp = \
                        'outputs/services_output/' +\
                        '{service_counter}__{name}.sh'
                    file_name_sh = file_name_sh_temp.format(
                        service_counter=service_counter,
                        name=d['name'])

                    with open(file_name_sh, 'w') as file:
                        content = self.create_kube_cmd.format(file=file_name)
                        file.write(content)
                    os.chmod(file_name_sh, stat.S_IRWXU)
                    sevice_cmds.append({'command': 'run', 'file': file_name_sh,
                                        'sleep': d.get('sleep')})

                    base_name = slugify(d['service'], separator="_")
                    backend = 'srvs__%s' % (base_name, )
                    temp_acls = []
                    for i in range(len(d['end_points'])):
                        temp_acls.append(
                            {'acl_name': 'app__{base_name}__{i}'.format(
                                base_name=base_name, i=i),
                             'url_path': d['end_points'][i],
                             'backend': backend})

                    dict_backend = {'backend': backend,
                                    'service': d['service'],
                                    'health-check': d['health-check'],
                                    'admin': d['admin'],
                                    'model': d['model']}

                    load_balancer_config['acls'].extend(temp_acls)
                    load_balancer_config['services'].append(dict_backend)
                    service_counter = service_counter + 1
                else:
                    raise Exception('Type not implemented: %s' % (d['type'], ))

        print("\n\n###Creating load balance files:")
        load_balancer = LoadBalancerMicroservice(
            haproxy_stats_user=self.haproxy_stats_user,
            haproxy_stats_password=self.haproxy_stats_password,
            haproxy_acls=load_balancer_config['acls'],
            haproxy_services=load_balancer_config['services'],
            kube_dns_ip=self.kube_dns_ip,
            gateway_public_ip=self.gateway_public_ip,
            gateway_ssl_cert_path=self.gateway_ssl_cert_path,
            gateway_ssl_key_path=self.gateway_ssl_key_path,
            gateway_ssl_dhparam_path=self.gateway_ssl_dhparam_path,
            version_nginx_gateway=self.version_nginx_gateway,
            firewall_ips=self.load_balancer_firewall_ips)

        temp_loadbalancer_deployments = load_balancer.create_deployment_file()
        load_balancer_counter = 0
        for d in temp_loadbalancer_deployments:
            if d['type'] in ['secrets', 'deploy']:
                file_name_temp = \
                    'resources/{load_balancer_counter}__{name}.yml'

                file_name = file_name_temp.format(
                    load_balancer_counter=load_balancer_counter,
                    name=d['name']
                )
                print('Creating secrets/deploy loadbalancer: ' + file_name)
                with open('outputs/load_balancer_output/' +
                          file_name, 'w') as file:
                    file.write(d['content'])

                file_name_sh_temp = \
                    'outputs/load_balancer_output/' + \
                    '{load_balancer_counter}__{name}.sh'
                file_name_sh = file_name_sh_temp.format(
                    load_balancer_counter=load_balancer_counter,
                    name=d['name'])
                with open(file_name_sh, 'w') as file:
                    content = self.create_kube_cmd.format(file=file_name)
                    file.write(content)
                os.chmod(file_name_sh, stat.S_IRWXU)

                load_balancer_cmds.append(
                    {'command': 'run', 'file': file_name_sh,
                     'sleep': d.get('sleep')})
                load_balancer_counter = load_balancer_counter + 1

            elif d['type'] == 'secrets_file':
                command_formated = d['content']
                template = '/outputs/load_balancer_output/' + \
                    '{load_balancer_counter}__{name}.sh'
                file_name = template.format(
                    load_balancer_counter=load_balancer_counter,
                    name=d['name'])

                print('Creating secrets_file loadbalancer: ' + file_name)
                with open(file_name, 'w') as file:
                    file.write(command_formated)
                os.chmod(file_name, stat.S_IRWXU)

                load_balancer_cmds.append(
                    {'command': 'run', 'file': file_name,
                     'sleep': d.get('sleep')})
                load_balancer_counter = load_balancer_counter + 1

            elif d['type'] == 'configmap':
                file_name_resource_temp = 'resources/{name}'
                file_name_resource = file_name_resource_temp.format(
                    name=d['file_name'])

                with open('outputs/load_balancer_output/' +
                          file_name_resource, 'w') as file:
                    file.write(d['content'])

                command_text = \
                    'SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"\n' + \
                    "kubectl delete configmap {name};\n" + \
                    "kubectl create configmap {name} " + \
                    '--from-file="$SCRIPTPATH/{file_name}"'
                command_formated = command_text.format(
                    name=d['name'], file_name=file_name_resource)

                template = 'outputs/load_balancer_output/' + \
                    '{load_balancer_counter}__{name}.sh'
                file_name = template.format(
                    load_balancer_counter=load_balancer_counter,
                    name=d['name'])

                print('Creating configmap loadbalancer: ' + file_name)
                with open(file_name, 'w') as file:
                    file.write(command_formated)
                os.chmod(file_name, stat.S_IRWXU)

                load_balancer_cmds.append({
                    'command': 'run', 'file': file_name,
                    'sleep': d.get('sleep')})
                load_balancer_counter = load_balancer_counter + 1

            elif d['type'] == 'services':
                template = 'resources/{service_counter}__{name}.yml'
                file_name = template.format(
                    service_counter=service_counter,
                    name=d['name'])
                print('Creating services loadbalancer: ' + file_name)

                with open('outputs/services_output/' + file_name, 'w') as file:
                    file.write(d['content'])

                template = 'outputs/services_output/' + \
                    '{service_counter}__{name}.sh'
                file_name_sh = template.format(
                    service_counter=service_counter,
                    name=d['name'])
                with open(file_name_sh, 'w') as file:
                    content = self.create_kube_cmd.format(file=file_name)
                    file.write(content)
                os.chmod(file_name_sh, stat.S_IRWXU)

                sevice_cmds.append({
                    'command': 'run', 'file': file_name_sh,
                    'sleep': d.get('sleep')})
                service_counter = service_counter + 1
            else:
                raise Exception('Type not implemented: %s' % (d['type'], ))

        return {
            'service_cmds': sevice_cmds,
            'microservice_cmds': deploy_cmds,
            'load_balancer_cmds': load_balancer_cmds,
        }

    def deploy_cluster(self):
        """Deploy cluster."""
        deploy_cmds = self.create_deploy_files()
        print('\n\n###Deploying Services:')
        self.kube_client.run_deploy_commmands(
            deploy_cmds['service_cmds'])

        print('\n\n###Deploying Load Balancer:')
        self.kube_client.run_deploy_commmands(
            deploy_cmds['load_balancer_cmds'])

        print('\n\n###Deploying Microservices:')
        self.kube_client.run_deploy_commmands(
            deploy_cmds['microservice_cmds'])
