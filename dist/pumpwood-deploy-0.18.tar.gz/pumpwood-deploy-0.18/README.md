# PumpWood Deploy
This package helps deploy of Pumpwood like components in Kubernets clusters.
It uses jinja templates to generate yml files to be apply using kubectrl.
This package was developed by Murabei Data Science and is under BSD-3-Clause
license.

<p align="center" width="60%">
  <img src="doc/sitelogo-horizontal.png" /> <br>

  <a href="https://en.wikipedia.org/wiki/Cecropia">
    Pumpwood is a native brasilian tree
  </a> which has a symbiotic relation with ants (Murabei)
</p>

# Quick Start
Each microservice is defined as and object which is added to the deployment
stack.
