import os
import base64
from .resources.yml__resorces import (
    beatbox_deployment, beatbox_secrets, rabbitmq_deployment, rabbitmq_secrets)
from .resources.postgres_init_configmap import (postgres_init_configmap)


class StandardMicroservices:
    """
    Create StandardMicroservices.

    Create RabbitMQ deployment and secrets, postgres-init-configmap config map
    for postgres initiation and storage bucket key secret.

    """

    def __init__(self, rabbit_username: str, rabbit_password: str,
                 beatbox_password: str,
                 beatbox_config_path: str, beatbox_version: str,
                 bucket_key_path: str):
        """
        __init__.

        Args:
            rabbit_username (str): rabbit_username for rabbitMQ login.
            rabbit_password (str): rabbit_password for rabbitMQ login.
            beatbox_password (str): beatbox microservice password.
            beatbox_version (str): Beatbox version.
            beatbox_config_path (str): Path to json configuration of beatbox
                calls.
            bucket_key_path (str): Path to bucket JSON key.
        """
        self._rabbit_username = base64.b64encode(
            rabbit_username.encode()).decode()
        self._rabbit_password = base64.b64encode(
            rabbit_password.encode()).decode()
        self._beatbox_password = base64.b64encode(
            beatbox_password.encode()).decode()
        self.beatbox_config_path = beatbox_config_path
        self.beatbox_version = beatbox_version
        self.end_points = []

        self.base_path = os.path.dirname(__file__)

        if not os.path.isfile(bucket_key_path):
            raise Exception("Bucket-Key path does not exist: %s" % (
                bucket_key_path, ))
        self.bucket_key_path = bucket_key_path

    def create_deployment_file(self):
        """create_deployment_file."""
        ##########
        # RabbitMQ
        secrets_text_formated = rabbitmq_secrets.format(
            username=self._rabbit_username, password=self._rabbit_password)

        #########
        # Beatbox
        with open(self.beatbox_config_path) as file:
            beatbox_configmap = file.read()
        beatbox_secrets_formated = beatbox_secrets.format(
            password=self._beatbox_password)
        beatbox_deployment_formated = beatbox_deployment.format(
            version=self.beatbox_version)

        #########
        # Bucket
        bucket_secret_cmd = """kubectl delete secret {name}; kubectl create secret generic {name} --from-file='{bucket_key_path}'""".format(
            name='bucket-key',
            bucket_key_path=self.bucket_key_path)

        return [
                # RabbitMQ
                {'type': 'secrets', 'name': 'rabbitmq__secrets',
                 'content': secrets_text_formated, 'sleep': 5},

                {'type': 'deploy', 'name': 'rabbitmq__deployment',
                 'content': rabbitmq_deployment, 'sleep': 0},

                # Postgres
                {'type': 'configmap', 'name': 'postgres-init-configmap',
                 'content': postgres_init_configmap,
                 'file_name': 'server_init.sh', 'sleep': 5},

                # BeatBox
                {'type': 'secrets', 'name': 'beatbox__secrets',
                 'content': beatbox_secrets_formated, 'sleep': 5},

                {'type': 'configmap', 'name': 'beatbox-configmap',
                 'content': beatbox_configmap,
                 'file_name': 'endpoints.json', 'sleep': 5},

                {'type': 'deploy', 'name': 'beatbox__deployment',
                 'content': beatbox_deployment_formated, 'sleep': 0},

                # Bucket
                {'type': 'secrets_file', 'name': 'bucket-key',
                 'content': bucket_secret_cmd, 'sleep': 5}]
