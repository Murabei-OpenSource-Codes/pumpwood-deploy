"""Google Trends data crawler module."""
import os


class PumpwoodModels:
    """
    Class to help deployment of StatsmodelsGLMModels.
    """

    def __init__(self, model_type: str, version: str,
                 bucket_name: str,
                 repository: str = "gcr.io/repositorio-geral-170012",
                 workers_timeout: int = 300):
        """
        __init__.

        Args:
            model_type (str): Model type.
            bucket_name (str): Name of the bucket to be used.
            version (str): Version of the model.
        Kwargs:
            repository (str): Repository path.
            workers_timeout (int): time in seconds to guinicorn wait for
                worker response.
        """
        self.base_path = os.path.dirname(__file__)
        self.model_type = model_type
        self.bucket_name = bucket_name
        self.repository = repository
        self.workers_timeout = workers_timeout
        self.version = version

    def create_deployment_file(self):
        """Create Google Trends deployment files."""
        with open(os.path.join(self.base_path, 'deploy/deployment_app.yml'),
                  'r') as file:
            deployment_app_text = file.read()
        deployment_app = deployment_app_text.format(
            model_type=self.model_type,
            bucket_name=self.bucket_name,
            repository=self.repository,
            version=self.version,
            workers_timeout=self.workers_timeout)

        with open(os.path.join(
                  self.base_path, 'deploy/deployment_estimation.yml'),
                  'r') as file:
            deployment_estimation_text = file.read()
        deployment_estimation = deployment_estimation_text.format(
            model_type=self.model_type,
            bucket_name=self.bucket_name,
            repository=self.repository,
            version=self.version)

        with open(os.path.join(
                  self.base_path, 'deploy/deployment_prediction.yml'),
                  'r') as file:
            deployment_prediction_text = file.read()
        deployment_prediction = deployment_prediction_text.format(
            model_type=self.model_type,
            bucket_name=self.bucket_name,
            repository=self.repository,
            version=self.version)

        return [
            {
                'type': 'deploy',
                'name': 'models__{}__app'.format(self.model_type),
                'content': deployment_app, 'sleep': 0},
            {
                'type': 'deploy',
                'name': 'models__{}__estimation'.format(self.model_type),
                'content': deployment_estimation, 'sleep': 0},
            {
                'type': 'deploy',
                'name': 'models__{}__prediction'.format(self.model_type),
                'content': deployment_prediction, 'sleep': 0}, ]

    def end_points(self):
        """Return microservices end-points."""
        return self.end_points
