kubectl delete deploy,persistentvolumeclaims,persistentvolumes,services --all
