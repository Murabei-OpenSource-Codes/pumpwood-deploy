======================
PumpWood Communication
======================

Package that facilitates inter-PumpWood communication

Quick start
-----------

1. Add "pumpwood-exceptions" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'pumpwood-communication',
    ]


