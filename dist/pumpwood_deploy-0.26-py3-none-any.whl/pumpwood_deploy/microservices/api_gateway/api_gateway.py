"""load_balancer.py."""
import os
from jinja2 import Template
from typing import List
from .resources.resources_yml import (
    kong_postgres_volume, kong_postgres_deployment, kong_deployment,
    external_service)


class ApiGateway:
    """
    KongApi Gateway.

    Args:
        gateway_public_ip(str): Public gateway IP.
        firewall_ips(str): List of the allowed IPs for at firewall.
    """

    def __init__(self, gateway_public_ip: str, kong_db_disk_name: str,
                 kong_db_disk_size: str, firewall_ips: List[str]):
        """
        Build deployment files for the Kong ApiGateway.

        Args:
            gateway_public_ip(str): Set the IP for the ApiGateway.
            kong_db_disk_name(str): Set the name of the disk for Kong Postgres.
            kong_db_disk_size(str): Set the size claimed from the Kong Postgres
                disk.
            firewall_ips(list[str]): Set a firewall restricting the calls for
                the IPs listed.
        Kwargs:

        """
        self.gateway_public_ip = gateway_public_ip
        self.firewall_ips = firewall_ips
        self.kong_db_disk_name = kong_db_disk_name
        self.kong_db_disk_size = kong_db_disk_size
        self.base_path = os.path.dirname(__file__)

    def create_deployment_file(self):
        """create_deployment_file."""

        kong_postgres_volume__formated = kong_postgres_volume.format(
            disk_size=self.kong_db_disk_size,
            disk_name=self.kong_db_disk_name)
        kong_postgres_deployment__formated = kong_postgres_deployment
        kong_deployment__formated = kong_deployment

        services__load_balancer_template = Template(
            external_service)
        svcs__load_balancer_text = services__load_balancer_template.render(
            public_ip=self.gateway_public_ip,
            firewall_ips=self.firewall_ips)

        to_return = [
            {'type': 'volume', 'name': 'kong__volume',
             'content': kong_postgres_volume__formated, 'sleep': 10},
            {'type': 'deploy', 'name': 'kong__postgres',
             'content': kong_postgres_deployment__formated, 'sleep': 0},
            {'type': 'deploy', 'name': 'kong__deploy',
             'content': kong_deployment__formated, 'sleep': 0},
            {'type': 'services',
             'name': 'apigateway__services',
             'content': svcs__load_balancer_text, 'sleep': 0}]
        return to_return
