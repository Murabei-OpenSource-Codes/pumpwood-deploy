"""Interface with kubernets."""

import subprocess


class Kubernets:
    """Class to auxiliate kubernets interface."""

    def __init__(self, cluster_name, zone, project):
        """
        __init__.

        Args:
            cluster_name (str): Kubernets cluster name.
            zone (str): Zone location of the cluster.
            project (str): Google project name:
            temp_deploy_path (str): Path to keep temp deploy files.
        """
        cmd = "gcloud container clusters get-credentials {cluster_name} " + \
            " --zone {zone} --project {project}"
        cmd_formated = cmd.format(cluster_name=cluster_name,
                                  zone=zone,
                                  project=project)

        print('Loging to kubernets cluster')
        process = subprocess.Popen(cmd_formated.split(),
                                   stdout=subprocess.PIPE)
        output, error = process.communicate()

        print('Getting cluster DNS IP')
        cmd = "kubectl --namespace=kube-system get services kube-dns"
        process = subprocess.Popen(cmd.split(), stdout=subprocess.PIPE)
        output, error = process.communicate()
        output_str = output.decode()
        output_str_splited = output_str.split('\n')

        if len(output_str_splited) != 3:
            raise Exception(
                'Error when geting cluster DNS ip:\n%s' % (output_str, ))

        header_split = output_str_splited[0].split()
        value_split = output_str_splited[1].split()
        values_in_dict = dict(zip(header_split, value_split))
        values_in_dict['CLUSTER-IP']

        self.cluster_dns_ip = values_in_dict['CLUSTER-IP']

    def get_cluster_dns_ip(self):
        """Get cluster DNS IP."""
        return self.cluster_dns_ip

    def run_deploy_commmands(self, cmds):
        """Deploy comands."""
        for c in cmds:
            if c['command'] == 'create':
                raise Exception('Not implemented')
            elif c['command'] == 'run':
                sleep_time = c.get('sleep', 10)
                if sleep_time is None:
                    sleep_time = 10
                print('###Running file: ' + c['file'])
                print('#####Slepping for %s seconds after' % (sleep_time, ))
                with open(c['file'], 'r') as file:
                    file_cmd = file.read()
                # Colocando o shebangs no inicio do arquivo
                with open(c['file'], 'w') as file:
                    file.write(
                        "#!/bin/sh\n" + file_cmd + "\nsleep %s" % (
                            sleep_time, ))
                subprocess.call(c['file'])
            else:
                raise Exception('Command not implemented: %s' % (
                    c['command'],))
