beatbox_deployment = """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: beatbox
spec:
  replicas: 1
  selector:
    matchLabels:
      type: queue
      queue: beatbox
  template:
    metadata:
      labels:
        type: queue
        queue: beatbox
    spec:
      imagePullSecrets:
        - name: dockercfg
      volumes:
      - name: beatbox-configmap
        configMap:
          name: beatbox-configmap
      restartPolicy: Always
      containers:
      - name: beatbox
        imagePullPolicy: Always
        resources:
          requests:
            cpu: "10m"
        image: gcr.io/repositorio-geral-170012/beatbox:{version}
        env:
        # Microsservice
        - name: MICROSERVICE_NAME
          value: 'pumpwood-beatbox'
        - name: MICROSERVICE_PASSWORD
          valueFrom:
            secretKeyRef:
              name: beatbox
              key: password
        volumeMounts:
        - name: beatbox-configmap
          mountPath: /worker/endpoints
"""


beatbox_secrets = """
apiVersion: v1
kind: Secret
metadata:
  name: beatbox
type: Opaque
data:
  password: {password}
"""

rabbitmq_deployment = """
apiVersion : "v1"
kind: Service
metadata:
  name: rabbitmq-main
  labels:
    type: queue
    queue: rabbitmq-main
spec:
  type: LoadBalancer
  ports:
    - name: ui
      port: 15672
      targetPort: 15672
    - name: broker
      port: 5672
      targetPort: 5672
  selector:
    type: queue
    queue: rabbitmq-main
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: rabbitmq-main
spec:
  replicas: 1
  selector:
    matchLabels:
      type: queue
      queue: rabbitmq-main
  template:
    metadata:
      labels:
        type: queue
        queue: rabbitmq-main
    spec:
      restartPolicy: Always
      volumes:
      - name: secrets
        secret:
          secretName: rabbitmq-main-secrets
      containers:
      - name: rabbitmq-main
        image: rabbitmq:3-management
        resources:
          requests:
            cpu: "1m"
        env:
        - name: RABBITMQ_DEFAULT_USER
          value: 'pumpwood'
        - name: RABBITMQ_DEFAULT_PASS
          valueFrom:
            secretKeyRef:
              name: rabbitmq-main-secrets
              key: password
        ports:
        - name: 'queue'
          containerPort: 5672
        - name: 'ui'
          containerPort: 15672
"""

rabbitmq_secrets = """
apiVersion: v1
kind: Secret
metadata:
  name: rabbitmq-main-secrets
type: Opaque
data:
  password: {password}
"""
